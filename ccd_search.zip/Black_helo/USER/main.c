/**
  * @file    main.c
  * @author  black helo
  * @version V1.0
  * @date    2020-10-08
  * @brief   ������
  */

#include "Black_All.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int page_last;  //��һҳ
int num1=0;     //��ӦP2.0����
int num2=0;     //��ӦP2.4
int X_1=0;      //��ӦP2.0
int X_2=0;      //��ӦP2.4
int dir1=0;     //�������
int dir2=0;     //�������

//�������ݱ���
int data[5]={0,0,0,0,0};//
extern char c[10];
extern char d[10];
extern int cont;    //��ʱ��ÿ10ms��1
extern int dist[2]; //���������������
int left_remember;  //��¼��·ռ�ձ�
int right_remember; //��¼��·ռ�ձȣ����ڷ�ֹ����ܵ�

////////////��·�������
#define L0 (P3IN & BIT0)
#define L1 (P3IN & BIT7)
#define L2 (P8IN & BIT2)
#define L3 (P7IN & BIT4)`
//#define M (P4IN & BIT0)
#define R0 (P4IN & BIT0)
#define R1 (P4IN & BIT3)
#define R2 (P1IN & BIT2)
#define R3 (P6IN & BIT0)
int road_search[8];
long result;
int remember;
const int low_bound=0;
int ji_lu=0;
int start_left;
int start_right;
int temp=7;
int speed_0;
int speed_1;
int speed_2;
int speed_3;
int speed_4;
int speed_5;
int speed_6;
int speed_7;
///////////////////

unsigned int cap_new = 0;           // �״β�׽��ta0rֵ
unsigned int cap_old = 0;           // ���β�׽��ta0rֵ
long cap_data = 0;                  // ����ֵ
/***********/
int zheng_fu=0;             //ƫ����������
int offset=0;               //ƫ�����ľ���ֵ
int open_set=0;             //open_mv������־
int cross_count;            //�յ��������
int number_recognition=0;    //����ʶ��
int direction=0;            //���ڿ�����Ȧ������Ȧ����ʱ�뻹��˳ʱ��
                            //11����Ȧ��ʱ�룻10����Ȧ˳ʱ�룻01����Ȧ��ʱ�룻00����Ȧ˳ʱ��

//����Ϊͷ�������ӳ���
int start_car=0;            //������־
int stop_cars=0;             //ͣ����־
int page=0;                 //����ģʽ��1-6ҳ�ֱ�Ϊ1-6��
int way_decide;              //����ʶ�𵽵�����ѡ��·��
int lowwer_speed;
int upper_speed;

extern int send_flag;
extern int send[5];
int master_speed;
int go_after_flag=0;
/**********/




extern u16 ADV[128];
void read()
{
    char_to_int(c);
    zheng_fu=data[0];
    offset=data[0]?-data[1]:data[1];
    open_set=data[2];
    cross_count=data[3];
    number_recognition=data[4];

    char_to_int(d);
    start_car=data[0];
    upper_speed=data[4];
    page=data[2];
    way_decide=data[3];
    lowwer_speed=data[1];
    master_speed=upper_speed*1000+lowwer_speed*10;

    //����38��ͷ��13����ٶȣ�34��β��13����ٶ�
    //    if(data[2]==0)
    //    {
    //        MOTOR2(0,38+(int)(0.5*cha));
    //        MOTOR1(0,38-(int)(0.5*cha));
    //    }
}
int down_array_remember[4]={0};
int down_array[4];
int cross_flag=1;
int way_order=1;
int cont_remember=0;
int guan_dian_count=0;
int count=0;
void readpc()
{
    RD_TSL();
    Dly_us();
    sendToPc();
}
void main(void)
{

    Init();
    OLED_Clear();
    while(1)
    {
          //readpc();
        RD_TSL();//��ccd��ֵ
        __delay_cycles(500);
        RD_TSL();

        if(guan_dian_count<21)
        {
            SPEED_CONTROL(35,(int)(0.5*(search_mid(ADV,cross_flag,way_order)-64)),0.5);
        }
        else if(guan_dian_count>=21)
        {
                MOTOR1(0,0);
                MOTOR2(0,0);
        }
//        if(cont%50==0)
//        {
//            OLED_Clear();
//            OLED_ShowVI(0,2,guan_dian_count,8);
//        }


//          ccd_show();

//        if(send_flag==1)
//        {
////            send[0]=direction;
////            send[1]=stop_cars;
////            send[2]=0;
////            send[3]=0;
////            send[4]=0;
////            send_sequece(send,0);
//            send_flag=0;
//        }
////        char_to_int(c);
////        offset=data[0]?-data[1]:data[1];
////        open_set=data[2];

////        offset=data[0]?-data[1]:data[1];
////        MOTOR2(0,(int)(34+(0.5*offset)));
////        MOTOR1(0,(int)(34-(0.5*offset)));
//
//        if((int)cont%5==0)
//        {
//        Hc_sr_Open();
//        }
//        if((int)cont%10==0)
//        {
//            if(page==0||page==1||page==2||page==3||page==4||page==5||page==6)
//            {
//                if(page!=page_last)
//                {
//                    OLED_Clear();
//
//                }
//            }
//            page_last=page;
//        }
    }
}




/*adc�������
ADC_7_Init();
_EINT();
while(1)
{
    ADC12CTL0 |=ADC12ENC;
    ADC12CTL0 |=ADC12SC;
    //__bis_SR_register(LPM4_bits+GIE);

    //__no_operation();
}
*/
/*OLED SHOW����Ҫ��ʾ��ʱ���޸�����ĺ�������
OLED_ShowVI(40,6,(int)cap_data,8);
OLED_ShowVI(40,5,(int)cont/100,8);
OLED_ShowVI(0,0,road_search[0],8);
OLED_ShowVI(0,1,road_search[1],8);
OLED_ShowVI(0,2,road_search[2],8);
OLED_ShowVI(0,3,road_search[3],8);
OLED_ShowVI(0,4,road_search[4],8);
OLED_ShowVI(0,5,road_search[5],8);
OLED_ShowVI(0,6,road_search[6],8);
OLED_ShowVI(0,7,road_search[7],8);
OLED_ShowNum(0,1,abs(dist[0]),5,8);
OLED_ShowNum(48,1,abs(dist[1]),5,8);
OLED_ShowNum(0,1,abs(num1),5,8);
OLED_ShowNum(40,1,abs(num2),5,8);
OLED_ShowVI(0,0,data[0],8);
OLED_ShowVI(0,1,data[1],8);
OLED_ShowVI(0,2,data[2],8);
OLED_ShowVI(0,3,data[3],8);
OLED_ShowVI(0,4,data[4],8);
OLED_ShowVI(40,7,(int)cap_data,8);
OLED_ShowVI(40,8,(int)cont/100,8);

//                    OLED_ShowVI(0,0,offset,8);
//                    OLED_ShowVI(0,1,cross_count,8);
//                    OLED_ShowVI(0,2,start_car,8);
//                    OLED_ShowVI(0,3,page,8);
//                    OLED_ShowVI(0,0,master_speed/10000%10,8);
//                    OLED_ShowVI(0,1,master_speed/1000%10,8);
//                    OLED_ShowVI(0,2,master_speed/100%10,8);
//                    OLED_ShowVI(0,3,master_speed/10%10,8);
//                    OLED_ShowVI(0,4,master_speed/1%10,8);
//                    OLED_ShowVI(40,4,lowwer_speed,8);
//                    OLED_ShowVI(40,3,upper_speed,8);
//
//                    OLED_ShowVI(0,0,dist[0]/10000%10,8);
//                    OLED_ShowVI(0,1,dist[0]/1000%10,8);
//                    OLED_ShowVI(0,2,dist[0]/100%10,8);
//                    OLED_ShowVI(0,3,dist[0]/10%10,8);
//                    OLED_ShowVI(0,4,dist[0]/1%10,8);
*/



