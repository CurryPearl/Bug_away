/*
 * Black_Define.h
 *
 *  Created on: 2020��10��7��
 *      Author: PC
 */

#ifndef USER_BLACK_DEFINE_H_
#define USER_BLACK_DEFINE_H_

#include <msp430.h>

#define LED0_Switch     1
#define LED1_Switch     1
#define KEY0_Switch     1
#define KEY1_Switch     1
#define USART0_switch   1
#define USART1_switch   1
#define PWM0_switch     0
#define PWM1_switch     0
#define PWM2_switch     1
#define PWM3_switch     1
#define OLED_switch     1
#define ADC_7           0
#define ADC_1           1
#define __ultra_sound   1
#define __motor         1
#define __encoder       1
#define __up_fre        1

#endif /* USER_BLACK_DEFINE_H_ */
