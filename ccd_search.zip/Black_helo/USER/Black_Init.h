/*
 * Black_Init.h
 *
 *  Created on: 2020��10��8��
 *      Author: PC
 */

#ifndef USER_BLACK_INIT_H_
#define USER_BLACK_INIT_H_

#include <msp430.h>

void Init(void);

#endif /* USER_BLACK_INIT_H_ */
