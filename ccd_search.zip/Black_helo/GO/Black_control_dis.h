/*
 * Black_control_dis.h
 *
 *  Created on: 2023��7��19��
 *      Author: Dell
 */

#ifndef GO_BLACK_CONTROL_DIS_H_
#define GO_BLACK_CONTROL_DIS_H_

void control_distance();



#endif /* GO_BLACK_CONTROL_DIS_H_ */
