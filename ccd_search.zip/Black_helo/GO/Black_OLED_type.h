/*
 * Black_OLED_type.h
 *
 *  Created on: 2020��10��8��
 *      Author: PC
 */

#ifndef GO_BLACK_OLED_TYPE_H_
#define GO_BLACK_OLED_TYPE_H_

#define u32 unsigned int
#define u16 unsigned short
#define u8 unsigned char

#endif /* GO_BLACK_OLED_TYPE_H_ */
