/*
 * Black_eight.c
 *
 *  Created on: 2023��7��18��
 *      Author: Dell
 */

#include"Black_eight.h"
#include<msp430.h>

#define L3 (P6IN & BIT1)
#define L2 (P8IN & BIT2)
#define L1 (P3IN & BIT7)
#define L0 (P3IN & BIT0)

#define R0 (P7IN & BIT4)
#define R1 (P4IN & BIT3)
#define R2 (P1IN & BIT2)
#define R3 (P6IN & BIT0)

extern int road_search[8];
extern int left_remember;
extern int right_remember;
extern long result;
extern int ji_lu;//��¼ʶ���˹յ�
void default_judge(int cross_flag)
{
    if(cross_flag==0)//��Ȧ
    {
        result=road_search[0]*10000000+road_search[1]*1000000+road_search[2]*100000;

    }
    else if(cross_flag==1)
    {
        result=road_search[5]*100+road_search[6]*10+road_search[7];
    }
    ji_lu=1;
}
void eight_search(int start_left,int start_right,int temp,int speed_0,int speed_1,int speed_2,int speed_3,int speed_4,int speed_5,int speed_6,int speed_7,int cross_flag)//���������Ȧ��Ȧ��Ȧ
{
    if(L3) road_search[0]=0;
    else road_search[0]=1;
    if(L2) road_search[1]=0;
    else road_search[1]=1;
    if(L1) road_search[2]=0;
    else road_search[2]=1;
    if(L0) road_search[3]=0;
    else road_search[3]=1;
    if(R0) road_search[4]=0;
    else road_search[4]=1;
    if(R1) road_search[5]=0;
    else road_search[5]=1;
    if(R2) road_search[6]=0;
    else road_search[6]=1;
    if(R3) road_search[7]=0;
    else road_search[7]=1;
    result=road_search[0]*10000000+road_search[1]*1000000+road_search[2]*100000+road_search[3]*10000+road_search[4]*1000+road_search[5]*100+road_search[6]*10+road_search[7];
    //������ͣ��
    //stop_car(cap_data);
    while(1)
    {
        ji_lu=0;
        switch(result)
            {
                //case 123456789: Motor_Speed_Adjust(0,0);break; //ͣ��
                case 10000:   Motor_Speed_Adjust(start_left-speed_0,start_right+speed_0); break;//��ƫ0��
                case 110000: Motor_Speed_Adjust(start_left-speed_1,start_right+speed_1); break;//��ƫ1��
                case 100000: Motor_Speed_Adjust(start_left-speed_2,start_right+speed_2); break;//��ƫ2��
                case 1100000: Motor_Speed_Adjust(start_left-speed_3,start_right+speed_3); break;//��ƫ3��
                case 1000000: Motor_Speed_Adjust(start_left-speed_4-temp,start_right+speed_4-temp); break;//��ƫ4��
                case 11000000: Motor_Speed_Adjust(start_left-speed_5-temp*2,start_right+speed_5-temp*2); break;//��ƫ5��
                case 10000000: Motor_Speed_Adjust(start_left-speed_6-temp*3,start_right+speed_6-temp*3); break;//��ƫ6��

                case 11000: Motor_Speed_Adjust(start_left,start_right);break;//ֱ����ʻ

                case 1000: Motor_Speed_Adjust(start_left+speed_0,start_right-speed_0);break;//��ƫ0��
                case 1100:Motor_Speed_Adjust(start_left+speed_1,start_right-speed_1); break;//��ƫ1��
                case 100:Motor_Speed_Adjust(start_left+speed_2,start_right-speed_2); break;//��ƫ2��
                case 110:Motor_Speed_Adjust(start_left+speed_3,start_right-speed_3); break;//��ƫ3��
                case 10:Motor_Speed_Adjust(start_left+speed_4-temp,start_right-speed_4-temp); break;//��ƫ4��
                case 11: Motor_Speed_Adjust(start_left+speed_5-temp*2,start_right-speed_5-temp*2); break;//��ƫ5��
                case 1: Motor_Speed_Adjust(start_left+speed_6-temp*3,start_right-speed_6-temp*3); break;//��ƫ6��
                default:break;//�����յ�
            }
            if(ji_lu==1)
            {
                default_judge(cross_flag);
                continue;
            }
            //�������ڼ��书�ܣ�������·��ʱ�ظ���һ�εĲ���
            else
            {
                MOTOR1(0,right_remember);
                MOTOR2(0,left_remember);
                break;
            }
    }
}

