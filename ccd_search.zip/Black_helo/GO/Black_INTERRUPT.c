/*
 * Black_INTERRUPT.c
 *
 *  Created on: 2020��10��8��
 *      Author: PC
 */

#include "Black_INTERRUPT.h"
#include"Black_LED.h"
#include"ultrasound.h"
#include"motor.h"
#include"Black_others.h"

#define L1 (P3IN & BIT7)
#define L2 (P8IN & BIT2)
#define M (P4IN & BIT0)
#define R1 (P4IN & BIT3)
#define R2 (P1IN & BIT2)

extern int road_search[5];
int i=0;
int k=0;
char c[10];
char d[10];
char rec[11];
char buf[11];
extern int page;
extern int X_1;    //��ӦP2.0
extern int X_2;    //��ӦP2.4
extern int dir1;
extern int dir2;
extern unsigned int cap_new;           // �״β�׽��ta0rֵ
extern unsigned int cap_old;           // ���β�׽��ta0rֵ
extern long cap_data;                  // ����ֵ
extern int num1;   //��ӦP2.0����
extern int num2;   //��ӦP2.4
int cont;
int dist[2];
int send[5];
extern int direction;


extern int zheng_fu;             //ƫ����������
extern int offset;               //ƫ�����ľ���ֵ
extern int open_set;             //open_mv������־
extern int cross_count;            //�յ��������
extern int number_recognition;    //����ʶ��
extern int direction;            //���ڿ�����Ȧ������Ȧ����ʱ�뻹��˳ʱ��
                            //11����Ȧ��ʱ�룻10����Ȧ˳ʱ�룻01����Ȧ��ʱ�룻00����Ȧ˳ʱ��

//����Ϊͷ�������ӳ���
extern int start_car;            //������־
extern int stop_cars;             //ͣ����־
extern int page;                 //����ģʽ��1-6ҳ�ֱ�Ϊ1-6��
extern int way_decide;              //����ʶ�𵽵�����ѡ��·��


void IN_Config(unsigned int x,unsigned int y)
{
    if(x == 1)
    {
        if(y == 1)
        {
            P2IE  |= BIT1;
            P2IES |= BIT1; //�½���
            P2IFG &= ~ BIT1;
            P2REN |= BIT1;
            P2OUT |= BIT1;
            _EINT();
        }
        else
        {
            P2IE  |= BIT1;
            P2IES &= ~ BIT1;//�Ͻ���
            P2IFG &= ~ BIT1;
            P2REN |= BIT1;
            P2OUT |= BIT1;
            _EINT();
        }
    }
    else
    {
        if(y == 1)
        {
            P1IE |= BIT1;
            P1IES |= BIT1;
            P1IFG &= ~ BIT1;
            P1REN |= BIT1;
            P1OUT |= BIT1;
            _EINT();
        }
        else
        {
            P1IE  |= BIT1;
            P1IES &= ~ BIT1;
            P1IFG &= ~ BIT1;
            P1REN |= BIT1;
            P1OUT |= BIT1;
            _EINT();
        }
    }
}


#pragma vector = USCI_A0_VECTOR
__interrupt void USCI_ISR()
{
    switch(_even_in_range(UCA0IV,4))
    {
        case 0:break;                             // Vector 0 - No interrupt
        case 2:                                   // Vector 2 - RXIFG
       // UCA0TXBUF = UCA0RXBUF;                // ���ͽ��յ�������
        rec[i]=UCA0RXBUF;
       if(rec[i]=='s')
           {
               int j;
                   i=1;
                   for (j = 1; j < 11; j++)
                   {
                       rec[j] = '0';
                   }
           }
       else if(rec[0]=='s' && i>0 )
           {
    //           c[i-1]=rec[i];
               i++;
               if(i>10)
               {
                   i=0;
                   int j;
                   for (j = 1; j < 11; j++)
                   {
                       c[j-1] = rec[j];
                   }
               }

           }

        break;
        case 4:break;                             // Vector 4 - TXIFG
        default: break;
    }
}

#pragma vector = USCI_A1_VECTOR
__interrupt void USCI_ISR2()
{
    switch(_even_in_range(UCA1IV,4))
    {
        case 0:break;                             // Vector 0 - No interrupt
        case 2:                                   // Vector 2 - RXIFG
       // UCA1TXBUF = UCA1RXBUF;                // ���ͽ��յ�������
        buf[k]=UCA1RXBUF;
       if(buf[k]=='s')
           {
               int j;
                   k=1;
                   for (j = 1; j < 11; j++)
                   {
                       buf[j] = '0';
                   }
           }
       else if(buf[0]=='s' && k>0 )
           {
               k++;
               if(k>10)
               {
                   k=0;
                   int j;
                   for (j = 1; j < 11; j++)
                   {
                       d[j-1] = buf[j];
                   }
               }

           }
        break;
        case 4:break;                             // Vector 4 - TXIFG
        default: break;
    }
}

#pragma vector = PORT2_VECTOR
__interrupt void P2_ISR(void)
{
    int a;
    if(P2IFG & BIT1)  //�ж��Ƿ���P2.1�������ж�
        {
            P2IFG &= ~BIT1;
            if((P2IN&BIT1)==0)
            {
                for(a=0;a<=1000;a++);  //��������������
                if((P2IN&BIT1) == 0)
                {
                    LED0_STATE(2);//����led1 ��

                }
            }
        }
    P2IFG &= ~BIT1;
}



#pragma vector = PORT1_VECTOR
__interrupt void P1_ISR(void)
{
    int a;
    if(P1IFG & BIT1)  //�ж��Ƿ���P1.1�������ж�
    {
       P1IFG &= ~BIT1;
       if((P1IN&BIT1) == 0)
       {
           for(a=0;a<=1000;a++);  //��������������
           if((P1IN&BIT1) == 0)
           {
               LED1_STATE(2);//����led1 ��
               if(page<=4&&page>0)
               {
                   page++;
               }
               else
               {
                   page=1;
               }
           }
       }
    }


}
#pragma vector=TIMER2_A1_VECTOR  //Timer_A�����ж����� p2.4
__interrupt void Timer_A2(void)
{
  switch(TA2IV)
  {
    case 2 :
        if(P1IN & BIT6)
            {X_2++;dir2=0;}
        else
            {X_2++;dir2=1;}
        break;
    case 4:
                if( TA2CCTL2 & CM_1)
                                {

                                    cap_new = TA2CCR2;
                                    TA2CCTL2 &= ~CM_1;
                                    TA2CCTL2 |=  CM_2;
                                }else if ( TA2CCTL2 & CM_2)
                                {
                                    cap_old = TA2CCR2;
                                    if((long)cap_old-(long)cap_new<0)
                                    {
                                        cap_data = 1.375*(65535+ cap_old - cap_new )/20*10/9;
                                    }
                                    else
                                    {
                                        cap_data = 1.375*(cap_old - cap_new )/20*10/9;
                                    }

                                    TA2CCTL2 &= ~CM_2;
                                    TA2CCTL2 |=  CM_1;
                                }
               break;
    default:
       // num2=X_2;
       // X_2=0;
        break;
  }
}

#pragma vector=TIMER1_A1_VECTOR  //Timer_A�����ж����� p2.0
__interrupt void Timer_A1(void)
{
  switch(TA1IV)
  {
    case 2 :
        if(P2IN & BIT7)
            {X_1++;dir1=0;}
        else
            {X_1++;dir1=1;}
    break;

    default:
      //  num1=X_1 ;
      // X_1=0;
            break;
  }
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{

}
extern int bee_flag;
int last_time=0;
int send_flag=0;
#pragma vector=TIMER0_B0_VECTOR
__interrupt void TIMERB0_ISR(void)
{
    cont+=1;
    if(cont%10==0)
    {
        num1=X_1;
        dist[0]+=X_1;
        X_1=0;
        num2=X_2;
        dist[1]+=X_2;
        X_2=0;
    }
    if(cont%5==0)
       {
           num1=X_1;
           dist[0]+=X_1;
           X_1=0;
           num2=X_2;
           dist[1]+=X_2;
           X_2=0;
       }
    if(bee_flag==1)
      {
          if(last_time==0) last_time=cont;
          if(cont-last_time>50)
          {
              last_time=0;
              bee_flag=0;
              OUTPUT_GPIO_State(2,2,1);
          }

      }
//    if(cont%10==0)
//    {
//       send_flag=1;
//    }

}
