/*
 * motot.h
 *
 *  Created on: 2023��7��11��
 *      Author: GG
 */

#ifndef GO_MOTOR_H_
#define GO_MOTOR_H_
#include <msp430.h>
void TIME();//������
void time_interupt();//��ʱ�ж���pwm�ҹ�
void MOTOR2(int dir,int pwm);
void MOTOR1(int dir,int pwm);
void speed_control(int speed1,int speed2);
//----------------------------------------------------//
void real_speed(float speed1,float speed2);// m/s





#endif /* GO_MOTOR_H_ */
