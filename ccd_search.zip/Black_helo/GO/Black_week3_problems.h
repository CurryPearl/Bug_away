/*
 * Black_week3_problems.h
 *
 *  Created on: 2023��7��18��
 *      Author: Dell
 */


#ifndef GO_BLACK_WEEK3_PROBLEMS_H_
#define GO_BLACK_WEEK3_PROBLEMS_H_

void SPEED_CONTROL(int speed,int cha,double parameter);
void TI_slave();//�ӳ�����
void Problem1();
void Problem2();
void Problem3();
void Problem4();
void Problem5();
void Problem6();
void run_way_1();
void run_way_2();
void run_way_3();
void run_way_4();
void concise_control();

#endif /* GO_BLACK_WEEK3_PROBLEMS_H_ */
