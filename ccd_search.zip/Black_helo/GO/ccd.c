/*
 * ccd.c
 *
 *  Created on: 2023��7��18��
 *      Author: GG
 */
#include <msp430.h>
#include"Black_GPIO.h"
#include"ccd.h"
#include"Black_adc.h"
#include "Black_USART.h"
#include "Black_OLED.h"

extern u16 ADV[128]={0};
u8 SciBuf[200];   //�洢�ϴ�����λ������Ϣ
void Dly_us(void)
{
   __delay_cycles(500);
}

/* p1.2 clk p4.3 SI  */
/**ccd��ֵ **/
void RD_TSL(void) {
  unsigned char i = 0;
  int tslp = 0;
  OUTPUT_GPIO_State(1,2,1); Dly_us();  OUTPUT_GPIO_State(4,3,0);  Dly_us();
  OUTPUT_GPIO_State(4,3,1); Dly_us(); OUTPUT_GPIO_State(1,2,0);  Dly_us();
  OUTPUT_GPIO_State(1,2,1); Dly_us();  OUTPUT_GPIO_State(4,3,0);   Dly_us();
  for (i = 0; i < 128; i++)  {
      OUTPUT_GPIO_State(1,2,0);
    Dly_us();  //�����ع�ʱ��
    Dly_us();  //�����ع�ʱ��
    _EINT();
    ADV[tslp] = adc_getvalue(0) >> 5;
//    if (tslp==85)ADV[tslp]+=20;
//    else if (tslp==86)ADV[tslp]+=20;
//    else if (tslp==87)ADV[tslp]+=20;
    tslp++;
    OUTPUT_GPIO_State(1,2,1);
    Dly_us();
    Dly_us();  //�����ع�ʱ��
  }
}
u8 ccd_value(int i)
{
    if(i>127) i=127;
    else if(i<0) i=0;
    return ADV[i];
}
void sendToPc(void)
  {
    int i;
    slove_data();
    send0_buf("*");
    send0_buf("LD");
    for(i=2;i<134;i++)
    {
        send0_buf(binToHex_high(SciBuf[i]));  //���ַ���ʽ���͸�4λ��Ӧ��16����
        send0_buf(binToHex_low(SciBuf[i]));   //���ַ���ʽ���͵�4λ��Ӧ��16����
    }
    send0_buf("00");   //ͨ��Э��Ҫ��
    send0_buf("#");    //ͨ��Э��Ҫ��
  }


extern int count;
extern int guan_dian_count;
void ccd_show()
{
    int max_val=0;
    int min_val=255;
    int r;
    for(r=0;r<128;r++)
    {
     int adc_ccd=ccd_value(r);
     if(max_val<adc_ccd&&r>16) max_val=adc_ccd;
     if(min_val>adc_ccd&&r>16) min_val=adc_ccd;
    }
    OLED_ShowString(0,0,"thres",8);
    OLED_ShowString(50,0,"max",8);
    OLED_ShowString(93,0,"min",8);
    OLED_ShowVI(0,1,(max_val+min_val)/2,8);
    OLED_ShowVI(35,1,max_val,8);
    OLED_ShowVI(78,1,min_val,8);



    for(r=0;r<128;r++)
    {
    int adc_ccd=ccd_value(r);
    int linear_adc_ccd=((adc_ccd - min_val) * (63 - 16)) / (max_val - min_val) + 16;
     draw_point(r,abs(linear_adc_ccd-63)+16);
    }
    for(r=0;r<128;r++)
    {
    int linear_thres=(((max_val+min_val)/2 - min_val) * (63 - 16)) / (max_val - min_val) + 16;
     draw_point(r,abs(linear_thres-63)+16);
    }
    __delay_cycles(1000000);
    OLED_Clear();

}
void slove_data(void)
{
int i;
RD_TSL();
SciBuf[0] = 0;
SciBuf[1] = 132;
SciBuf[2] = 0;
SciBuf[3] = 0;
SciBuf[4] = 0;
SciBuf[5] = 0;
for(i=0;i<128;i++)
 SciBuf[6+i] = ADV[i];
}
/////////�������Ƶ�8λת��Ϊ16����//////////
char* binToHex_low(u8 num)
{u8 low_four;
low_four=num&0x0f;
if(low_four==0)
return("0");
else if(low_four==1)
 return("1");
else if(low_four==2)
 return("2");
else if(low_four==3)
 return("3");
else if(low_four==4)
 return("4");
else if(low_four==5)
 return("5");
else if(low_four==6)
 return("6");
else if(low_four==7)
 return("7");
else if(low_four==8)
 return("8");
else if(low_four==9)
 return("9");
else if(low_four==10)
 return("A");
else if(low_four==11)
 return("B");
else if(low_four==12)
 return("C");
else if(low_four==13)
 return("D");
else if(low_four==14)
 return("E");
else if(low_four==15)
 return("F");
}
//////////�������Ƹ�8λת��16����//////////
char* binToHex_high(u8 num)
{
u8 high_four;
high_four=(num>>4)&0x0f;
if(high_four==0)
return("0");
else if(high_four==1)
return("1");
else if(high_four==2)
return("2");
else if(high_four==3)
return("3");
else if(high_four==4)
return("4");
else if(high_four==5)
return("5");
else if(high_four==6)
return("6");
else if(high_four==7)
return("7");
else if(high_four==8)
return("8");
else if(high_four==9)
return("9");
else if(high_four==10)
return("A");
else if(high_four==11)
return("B");
else if(high_four==12)
return("C");
else if(high_four==13)
return("D");
else if(high_four==14)
return("E");
else if(high_four==15)
return("F");
}


//count_startΪ��α�������ʼ��������_thresholdΪ��ֵ��down_startΪ�ȵ׵���㣬
int down_mid(int count_start[],int _threshold)
{
    //count_start=15;
    int i;
    int remember = 1;
    int down_start=15;
    int down_end=15;
    for (i = count_start[0];i <= 115;i++)
    {
        if (ADV[i] < _threshold&&ADV[i+1] < _threshold&&ADV[i+2] < _threshold)
        {
            if (remember)
            {
                down_start = i;
                remember = 0;
            }
        }
        else if (ADV[i] > _threshold &&ADV[i+1] > _threshold&&ADV[i+2] > _threshold &&remember == 0)
        {
            down_end = i+2;
            count_start[0] = i+2;
            break;
        }
    }
    if (remember==1)
    {
        return 0;
    }
    else if(remember==0)
    {
        return (int)((down_start + down_end) * 0.5);
    }
}


extern int cont;
extern int cont_remember;
extern int down_array[4];
extern int down_array_remember[4];
extern int guan_dian_count;

int search_mid(int ADV[],int cross_flag, int way_order)
{
    int _threshold;
    int min_val = ADV[16];
    int max_val = ADV[16];
    count=0;

    int count_start[1];
    count_start[0]=15;
    int average = 0;
    int i;
    for(i=0;i<4;i++)
    {
        down_array_remember[i] = down_array[i];
    }
    for (i = 15; i <= 113; i++)
    {
        if (ADV[i] < min_val)
        {
            min_val = ADV[i];
        }
        if (ADV[i] > max_val)
        {
            max_val = ADV[i];
        }
        average += ADV[i] / 86.0;
    }
//ʮ�����ֵ�޳�����
//    for (int i = 0; i < 86; i++) {
//        average += list_sort[i] / 86.0;
//    }
    //_threshold = (int)((average) / 2.0 + 12);
    _threshold = min_val+20;
    if (abs(max_val - _threshold) < 25)
    {
        for(i=0;i<4;i++)
        {
            down_array[i] = down_array_remember[i];
        }
    }
    else
    {
        for (i = 0; i < 4; i++)
        {
            if (count_start[0] > 115)
            {
                break;
            }
            else
            {
                down_array[i] = down_mid(count_start,_threshold);
            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        if (down_array[i] != 0)
        {
            count += 1;
        }
    }
    if (count == 2)
    {
        bee();
        if (cont - cont_remember > 170)
        {
            guan_dian_count += 1;
            cont_remember = cont;
        }
        int result;
        if (way_order == 1)
        {
            if (cross_flag == 1)
            {
                for (i = 3; i >= 0; i--)
                {
                    if (down_array[i] != 0)
                    {
                        result = down_array[i];
                        break;
                    }
                }
            }
        else if (cross_flag == 0)
            {
                for (i = 0; i < 4; i++)
                {
                    if (down_array[i] != 0)
                    {
                        result = down_array[i];
                        break;
                    }
                }
            }
        }
        else if (way_order == 0)
        {
            if (cross_flag == 1)
            {
                for (i = 0; i < 4; i++)
                {
                    if (down_array[i] != 0)
                    {
                        result = down_array[i];
                        break;
                    }
                }
            }
            else if (cross_flag == 0)
            {
                for (i = 3; i >= 0; i--)
                {
                    if (down_array[i] != 0)
                    {
                        result = down_array[i];
                        break;
                    }
                }
            }
        }
        return result;
    }
    else
    {
        int result;
        for (i = 0; i < 4; i++)
        {
            if (down_array[i] != 0)
            {
                result = down_array[i];
                break;
            }
        }
        return result;
    }
}
