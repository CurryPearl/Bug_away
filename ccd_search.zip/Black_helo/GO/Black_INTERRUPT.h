/*
 * Black_INTERRUPT.h
 *
 *  Created on: 2020��10��8��
 *      Author: PC
 */

#ifndef GO_BLACK_INTERRUPT_H_
#define GO_BLACK_INTERRUPT_H_

#include <msp430.h>

void IN_Config(unsigned int x,unsigned int y);

#endif /* GO_BLACK_INTERRUPT_H_ */
