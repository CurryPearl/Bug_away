/*
 * Black_control_dis.c
 *
 *  Created on: 2023��7��19��
 *      Author: Dell
 */
#include"Black_control_dis.h"

extern long cap_data;
void control_distance()
{
    if(cap_data<200)
    {
        //35ռ�ձ��ٶ�
        eight_search(30,39,0,5,5,5,5,9,9,9,9);
    }
    else if(cap_data>=200&&cap_data<300)
    {
        //45ռ�ձ��ٶ�
        eight_search(30,39,0,5,5,5,5,9,9,9,9);
    }
    else if(cap_data>=300)
    {
        //55ռ�ձ��ٶ�
        eight_search(30,39,0,5,5,5,5,9,9,9,9);
    }
}

